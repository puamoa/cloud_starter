import './assets/main.css';
import 'bootstrap/dist/css/bootstrap.css';
import 'vue-awesome-paginate/dist/style.css';

import { useKakao } from 'vue3-kakao-maps/@utils';
// const rest_api_key = 'Api Key'; // Javascript 키 값
// main.js 수정
const rest_api_key = import.meta.env.VITE_KAKAO_KEY;

useKakao(rest_api_key, ['services']);

import { createApp } from 'vue';
import { createPinia } from 'pinia';
import VueAwesomePaginate from 'vue-awesome-paginate';

import App from './App.vue';
import router from './router';

import axios from 'axios';
axios.defaults.baseURL = import.meta.env.VITE_API_URL || '';

const app = createApp(App);

app.use(VueAwesomePaginate);
app.use(createPinia());
app.use(router);

app.mount('#app');
