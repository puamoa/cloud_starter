#!/bin/bash
# travel.csv, travel_image.csv 데이터 로드
# docker-entrypoint-initdb.d에서 자동 실행됨

mysql -u root -p$MYSQL_ROOT_PASSWORD myapp --local-infile=1 -e "
LOAD DATA LOCAL INFILE '/docker-entrypoint-initdb.d/travel.csv'
INTO TABLE tbl_travel
FIELDS TERMINATED BY ','
ENCLOSED BY '\"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(no, district, title, description, address, phone);
"

mysql -u root -p$MYSQL_ROOT_PASSWORD myapp --local-infile=1 -e "
LOAD DATA LOCAL INFILE '/docker-entrypoint-initdb.d/travel_image.csv'
INTO TABLE tbl_travel_image
FIELDS TERMINATED BY ','
ENCLOSED BY '\"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(filename, travel_no);
"

echo "✅ travel 데이터 로드 완료"
