USE myapp;

DROP TABLE IF EXISTS tbl_member_auth;
DROP TABLE IF EXISTS tbl_member;

CREATE TABLE tbl_member (
    username    VARCHAR(50)  PRIMARY KEY,
    password    VARCHAR(128) NOT NULL,
    email       VARCHAR(50)  NOT NULL,
    reg_date    DATETIME DEFAULT now(),
    update_date DATETIME DEFAULT now()
);

CREATE TABLE tbl_member_auth (
    username    VARCHAR(50) NOT NULL,
    auth        VARCHAR(50) NOT NULL,
    PRIMARY KEY(username, auth),
    CONSTRAINT fk_authorities_users FOREIGN KEY (username) REFERENCES tbl_member(username)
);

-- 테스트 사용자 (비밀번호: 1234, BCrypt 인코딩)
INSERT INTO tbl_member(username, password, email)
VALUES
    ('admin', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'admin@galapagos.org'),
    ('user0', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'user0@galapagos.org'),
    ('user1', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'user1@galapagos.org'),
    ('user2', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'user2@galapagos.org'),
    ('user3', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'user3@galapagos.org'),
    ('user4', '$2a$10$btIzOEivxCWBs02nasj6zuO6mlcY5pJRry5rlMccI9KRBptwmUu2e', 'user4@galapagos.org');

INSERT INTO tbl_member_auth(username, auth)
VALUES
    ('admin', 'ROLE_ADMIN'),
    ('admin', 'ROLE_MANAGER'),
    ('admin', 'ROLE_MEMBER'),
    ('user0', 'ROLE_MANAGER'),
    ('user0', 'ROLE_MEMBER'),
    ('user1', 'ROLE_MEMBER'),
    ('user2', 'ROLE_MEMBER'),
    ('user3', 'ROLE_MEMBER'),
    ('user4', 'ROLE_MEMBER');
