-- Step 9 Docker 실습용 DB 초기화
-- docker-compose: /docker-entrypoint-initdb.d/ 에 마운트하여 자동 실행
-- RDS: mysql -h <endpoint> -u admin -p < 00-init.sql 로 수동 실행

CREATE DATABASE IF NOT EXISTS myapp
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE myapp;
